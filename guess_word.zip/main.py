import sys

import requests
from PySide6.QtCore import Slot, QThread, Signal
from PySide6.QtGui import QFontDatabase, QFont
from PySide6.QtWidgets import QMainWindow, QWidget, QStackedWidget, QApplication

from screens.game_page import Ui_gamePage
from screens.main_page import Ui_mainPage

from resources import resources_rc


class ApiRequestThread(QThread):
    data_received = Signal(dict)
    error_occurred = Signal(str)

    def run(self):
        try:
            # Имитируем задержку, как будто долгий запрос
            params = {"category": "Животные"}
            response = requests.get("http://127.0.0.1:8001/v1/word/random", params=params)
            response.raise_for_status()
            data = response.json()
            self.data_received.emit(data)
        except Exception as e:
            self.error_occurred.emit(str(e))


class MainPage(QWidget, Ui_mainPage):
    def __init__(self):
        super(MainPage, self).__init__()
        self.setupUi(self)



class GamePage(QWidget, Ui_gamePage):
    def __init__(self):
        super(GamePage, self).__init__()
        self.setupUi(self)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.main_page = MainPage()
        self.game_page = GamePage()

        self.stackedWidget = QStackedWidget()
        self.stackedWidget.addWidget(self.main_page)
        self.stackedWidget.addWidget(self.game_page)

        self.setCentralWidget(self.stackedWidget)

        self.main_page.btnMainExit.clicked.connect(self.close)
        self.main_page.btnStart.clicked.connect(self.start_game)
        self.game_page.gameButtonMainMenu.clicked.connect(self.main_menu)


    def start_game(self):
        self.stackedWidget.setCurrentIndex(1)

        self.thread = ApiRequestThread()
        self.thread.data_received.connect(self.show_data)
        self.thread.error_occurred.connect(self.show_error)
        self.thread.start()

    def main_menu(self):
        self.stackedWidget.setCurrentIndex(0)

    @Slot()
    def load_data(self):

        self.thread = ApiRequestThread()
        self.thread.data_received.connect(self.show_data)
        self.thread.error_occurred.connect(self.show_error)
        self.thread.start()

    @Slot(dict)
    def show_data(self, data):
        print(data)
        self.game_page.gameCategoryText.setText(data.get("category", "Неизвестно"))
        self.game_page.gameHintText.setText(data.get("tell", "Отсутствует"))
        self.game_page.encryptedWordText.setText(data.get("word", "Ошибка"))

    @Slot(str)
    def show_error(self, error):
        self.label.setText(f"Ошибка: {error}")
        self.button.setEnabled(True)



if __name__ == '__main__':
    app = QApplication(sys.argv)
    fonts = [QFontDatabase.addApplicationFont("resources/fonts/NunitoSans-SemiBold.ttf"),
             QFontDatabase.addApplicationFont("resources/fonts/NunitoSans-Regular.ttf"),]

    for font in fonts:
        if font == -1:
            print("Ошибка: не удалось загрузить шрифт")
        else:
            family = QFontDatabase.applicationFontFamilies(font)
            if family:
                print(f"Шрифт загружен: {family[0]}")

    app.setFont(QFont("NunitoSans"))

    window = MainWindow()
    window.show()
    sys.exit(app.exec())
